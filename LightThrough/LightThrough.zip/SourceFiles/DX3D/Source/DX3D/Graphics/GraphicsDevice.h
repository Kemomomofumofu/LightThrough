#pragma once

/**
 * @file GraphicsDevice.h
 * @brief �O���t�B�b�N�f�o�C�X
 * @author Arima Keita
 * @date 2025-07-14
 */

 /*---------- �C���N���[�h ----------*/
#include <DX3D/Graphics/GraphicsResource.h>
#include <DX3D/Core/common.h>
#include <DX3D/Core/Base.h>
#include <d3d11.h>
#include <wrl.h>

namespace dx3d {
	class GraphicsDevice final : public Base, public std::enable_shared_from_this<GraphicsDevice> {
	public:
		explicit GraphicsDevice(const GraphicsDeviceDesc& _desc);
		virtual ~GraphicsDevice() override;

		SwapChainPtr CreateSwapChain(const SwapChainDesc& _desc);
		DeviceContextPtr CreateDeviceContext();
		ShaderBinaryPtr CompileShader(const ShaderCompileDesc& _desc);
		GraphicsPipelineStatePtr CreateGraphicsPipelineState(const GraphicsPipelineStateDesc& _desc);
		VertexBufferPtr CreateVertexBuffer(const VertexBufferDesc& _desc);
		VertexShaderSignaturePtr CreateVertexShaderSignature(const VertexShaderSignatureDesc& _desc);

		void ExecuteCommandList(DeviceContext& _context);

	private:
		GraphicsResourceDesc GetGraphicsResourceDesc() const noexcept;

	private:
		Microsoft::WRL::ComPtr<ID3D11Device> d3d_device_{};					// �f�o�C�X
		Microsoft::WRL::ComPtr<ID3D11DeviceContext> d3d_context_{};	// �f�o�C�X�R���e�L�X�g
		Microsoft::WRL::ComPtr<IDXGIDevice> dxgi_device_{};		// GPU��Windows�̋�
		Microsoft::WRL::ComPtr<IDXGIAdapter> dxgi_adapter_{};		// GPU�̏��������Ă���
		Microsoft::WRL::ComPtr<IDXGIFactory> dxgi_factory_{};		// �X���b�v�`�F�C�����������
	};
}