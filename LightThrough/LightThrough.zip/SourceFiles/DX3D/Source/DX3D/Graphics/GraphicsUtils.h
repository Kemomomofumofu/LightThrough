#pragma once
/**
 * @file GraphicsUtils.h
 * @brief �O���t�B�b�N�⏕�@�\
 * @author Arima Keita
 * @date 2025-06-25
 */

 /*---------- �C���N���[�h ----------*/
#include <DX3D/Core/Common.h>
#include <d3d11.h>
#include <bit>

/**
 * @brief GraphicsUtils
 *
 * �����_���[�ɑ΂��Ċy�ɂȂ�⏕�I�ȏ������l�ߍ��ދ��
 */
namespace dx3d {
	namespace GraphicsUtils {
		inline const char* GetShaderModelTarget(ShaderType _type) {
			switch (_type) {
			case ShaderType::VertexShader:	return "vs_5_0";
			case ShaderType::PixelShader:	return "ps_5_0";
			default:						return "";
			}
		}

		inline DXGI_FORMAT GetDXGIFormatFromMask(D3D_REGISTER_COMPONENT_TYPE _type, UINT _mask) {
			auto componentCount = std::popcount(_mask);
			if (componentCount < 1) {
				return DXGI_FORMAT_UNKNOWN;
			}

			constexpr DXGI_FORMAT formatTable[1][4] = {
				{
					DXGI_FORMAT_R32_FLOAT,
					DXGI_FORMAT_R32G32_FLOAT,
					DXGI_FORMAT_R32G32B32_FLOAT,
					DXGI_FORMAT_R32G32B32A32_FLOAT,
				}
			};

			auto typeIndex = 0u;
			switch (_type) {
			case D3D_REGISTER_COMPONENT_FLOAT32: typeIndex = 0u; break;
			default: return DXGI_FORMAT_UNKNOWN;
			}

			return formatTable[0][componentCount - 1];
		};
	}
}