#pragma once

/**
 * @file StaticMesh.h
 * @brief �悭����}�`
 * @author Arima Keita
 * @date 2025-08-22
 */

// ---------- �C���N���[�h ---------- // 
#include <DX3D/Core/Common.h>
#include <DX3D/Graphics/GraphicsResource.h>

namespace dx3d {
	struct StaticMeshDesc {
		const VertexBufferDesc vb{};
		const IndexBufferDesc ib{};
	};
	/**
	 * @brief �悭����}�`
	 */
	class StaticMesh : public GraphicsResource{
	public:
		StaticMesh(const StaticMeshDesc& _desc);
		void Draw(ID3D11DeviceContext* _ctx);

	private:
		Microsoft::WRL::ComPtr<ID3D11Buffer> vertex_buffer_{};
		Microsoft::WRL::ComPtr<ID3D11Buffer> index_buffer_{};
		UINT index_count_{};
	};
}