/**
 * @file ecs/Coordinator.cpp
 * @brief ECS���ꌳ�Ǘ�����N���X
 * @author Arima Keita
 * @date 2025-08-15
 */

// ---------- �C���N���[�h ---------- // 
#include <DX3D/Game/ECS/Coordinator.h>



/**
 * @brief ������
 */
void ecs::Coordinator::Init()
{
	entity_manager_ = std::make_unique<EntityManager>();
	component_manager_ = std::make_unique<ComponentManager>();
	system_manager_ = std::make_unique<SystemManager>();
}

/**
 * @brief Entity�𐶐�
 * @return �������ꂽEntity
 */
ecs::Entity ecs::Coordinator::CreateEntity() {
	return entity_manager_->Create();
}

/**
 * @brief Entity�̔j��
 * @param _e �Ώۂ�Entity
 */
void ecs::Coordinator::DestroyEntity(Entity _e)
{
	entity_manager_->Destroy(_e);
	component_manager_->EntityDestroyed(_e);
	system_manager_->EntityDestroyed(_e);
}
