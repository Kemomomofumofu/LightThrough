#pragma once

/**
 * @file All.h
 * @brief 
 * @author Arima Keita
 * @date 2025-06-25
 */

 /*---------- �C���N���[�h ----------*/
#include <DX3D/Game/Game.h>